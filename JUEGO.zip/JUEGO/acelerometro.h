#ifndef acelerometro_h
#define acelerometro_h

#include "stm32f4xx_hal.h"
#include "cmsis_os2.h"    
#include "Driver_SPI.h"

int Init_ThMPU (void);

osThreadId_t get_ThMPU_Id(void);


#endif
