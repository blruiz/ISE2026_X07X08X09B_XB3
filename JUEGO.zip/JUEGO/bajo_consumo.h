#ifndef __bajo_consumo_H
#define __bajo_consumo_H

#include "stm32f4xx_hal.h"
#include <stdio.h>
#include "cmsis_os2.h"

extern int Init_Th_BajoConsumo (void);


osThreadId_t get_ThBC_Id(void);

#endif
