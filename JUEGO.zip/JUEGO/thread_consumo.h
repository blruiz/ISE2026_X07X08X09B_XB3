#ifndef THREAD_CONSUMO_H
#define THREAD_CONSUMO_H

#include "cmsis_os2.h"

int Init_ThConsumo (void);

osThreadId_t get_ThConsumo_Id(void);

#endif // THREAD_CONSUMO_H
