#include "usart.h"
#include "juego.h"
#include <string.h>
#include <stdio.h>

extern ARM_DRIVER_USART Driver_USART7;
static ARM_DRIVER_USART *USARTdrv = &Driver_USART7;

/* ------------------ RTOS IDs ------------------ */
osThreadId_t tid_Th_FO;
osMessageQueueId_t mid_MsgQueueFO;

/* ------------------ TX ------------------ */
FO_MSG_t objetoLocal;

/* ------------------ RX ------------------ */
static uint8_t rxByte;

/* Flags internas del hilo FO */
#define FO_FLAG_RX   0x01
#define FO_FLAG_TX   0x02

/* ------------------ Parser RX byte a byte ------------------ */
typedef enum {
    RX_WAIT_START = 0,
    RX_WAIT_FUNC,
    RX_WAIT_DATA,
    RX_WAIT_END
} FO_RxState_t;

static FO_RxState_t rxState = RX_WAIT_START;
static uint8_t rxFunc = 0;
static uint8_t rxData = 0;

/* ------------------ Prototipos ------------------ */
static void myUSART_callback(uint32_t event);
static void Thread_FO(void *argument);
static void init_UART(void);
static int Init_Th(void);
static int Init_MsgQueue(void);

static void FO_ResetParser(void);
static void FO_ParseByte(uint8_t byte);
static void FO_ProcessFrame(uint8_t funcion, uint8_t valor);

/* ========================================================= */
/*                      API P�BLICA                          */
/* ========================================================= */

void Init_FO(void) {
    init_UART();
    Init_MsgQueue();
    Init_Th();
}

void enviarDatos(uint8_t funcion, uint8_t valor) {
    FO_MSG_t mensaje;

    mensaje.data[0] = START_BYTE;
    mensaje.data[1] = funcion;
    mensaje.data[2] = valor;
    mensaje.data[3] = END_BYTE;

    // Si la cola estuviera llena, simplemente se pierde el mensaje.
if (osMessageQueuePut(mid_MsgQueueFO, &mensaje, 0U, 0U) != osOK) {
//    printf("Cola uart llena, trama perdida\n");
				}
}

/* ========================================================= */
/*                      CALLBACK USART                       */
/* ========================================================= */

static void myUSART_callback(uint32_t event) {

    if (event & ARM_USART_EVENT_RECEIVE_COMPLETE) {
        osThreadFlagsSet(tid_Th_FO, FO_FLAG_RX);
    }

    if (event & ARM_USART_EVENT_SEND_COMPLETE) {
        osThreadFlagsSet(tid_Th_FO, FO_FLAG_TX);
    }

    /* Si quieres, luego podemos tratar:
       - ARM_USART_EVENT_RX_TIMEOUT
       - ARM_USART_EVENT_RX_OVERFLOW
       - ARM_USART_EVENT_TX_UNDERFLOW
       De momento no hace falta para que funcione el parser. */
}

/* ========================================================= */
/*                       HILO FO                             */
/* ========================================================= */

static void Thread_FO(void *argument) {

    uint32_t flags;

    /* Armamos primera recepci�n de 1 byte */
    USARTdrv->Receive(&rxByte, 1);

    while (1) {

        /* ---------------- ENV�O ---------------- */
        if (osMessageQueueGet(mid_MsgQueueFO, &objetoLocal, NULL, 0) == osOK) {

            USARTdrv->Send(objetoLocal.data, 4);

            /* Esperar fin de TX de forma robusta */
            flags = osThreadFlagsWait(FO_FLAG_TX, osFlagsWaitAny, 100);

            if ((flags & osFlagsError) != 0) {
                /* Si quieres debug real, usar LED o UART de debug real.
                   Evitar printf si te rompe standalone. */
            }
        }

        /* ---------------- RECEPCI�N ---------------- */
        flags = osThreadFlagsWait(FO_FLAG_RX, osFlagsWaitAny, 10);

        if ((flags & osFlagsError) == 0 && (flags & FO_FLAG_RX)) {

            /* Procesar byte recibido */
            FO_ParseByte(rxByte);

            /* Rearmar recepci�n del siguiente byte */
            USARTdrv->Receive(&rxByte, 1);
        }

        osDelay(1);
    }
}

/* ========================================================= */
/*                    PARSER DE TRAMAS                       */
/* ========================================================= */

static void FO_ResetParser(void) {
    rxState = RX_WAIT_START;
    rxFunc  = 0;
    rxData  = 0;
}

static void FO_ParseByte(uint8_t byte) {

    switch (rxState) {

        case RX_WAIT_START:
            if (byte == START_BYTE) {
                rxState = RX_WAIT_FUNC;
            }
            break;

        case RX_WAIT_FUNC:
            rxFunc = byte;
            rxState = RX_WAIT_DATA;
            break;

        case RX_WAIT_DATA:
            rxData = byte;
            rxState = RX_WAIT_END;
            break;

        case RX_WAIT_END:
            if (byte == END_BYTE) {
                /* Trama v�lida completa */
                FO_ProcessFrame(rxFunc, rxData);
                FO_ResetParser();
            }
            else if (byte == START_BYTE) {
                /* Posible nueva trama solapada:
                   el byte actual ya puede ser el START de la siguiente */
                rxState = RX_WAIT_FUNC;
            }
            else {
                /* basura / desalineaci�n */
                FO_ResetParser();
            }
            break;

        default:
            FO_ResetParser();
            break;
    }
}

/* ========================================================= */
/*                 PROCESADO DE MENSAJES RX                  */
/* ========================================================= */

static void FO_ProcessFrame(uint8_t funcion, uint8_t valor) {

    switch (funcion) {

        case INI_JUEGO:
            /* Solo aceptar si el tercer byte vale 0x00 */
            if (valor == 0x00) {
                osThreadFlagsSet(get_ThJuego_Id(), JUGAR);
//              printf("Inicio pulsado\n");
            }
            break;

        /* Si m�s adelante quieres procesar m�s comandos recibidos
           desde el servidor, los a�adir�as aqu� */

        default:
            /* Mensaje desconocido: ignorar */
            break;
    }
}

/* ========================================================= */
/*                     INICIALIZACI�N                        */
/* ========================================================= */

static void init_UART(void) {

    USARTdrv->Initialize(myUSART_callback);
    USARTdrv->PowerControl(ARM_POWER_FULL);

    USARTdrv->Control(ARM_USART_MODE_ASYNCHRONOUS |
                      ARM_USART_DATA_BITS_8 |
                      ARM_USART_PARITY_NONE |
                      ARM_USART_STOP_BITS_1 |
                      ARM_USART_FLOW_CONTROL_NONE,
                      9600);

    USARTdrv->Control(ARM_USART_CONTROL_TX, 1);
    USARTdrv->Control(ARM_USART_CONTROL_RX, 1);
}

static int Init_Th(void) {

    tid_Th_FO = osThreadNew(Thread_FO, NULL, NULL);

    if (tid_Th_FO == NULL) {
        return -1;
    }

    return 0;
}

static int Init_MsgQueue(void) {

    mid_MsgQueueFO = osMessageQueueNew(8, sizeof(FO_MSG_t), NULL);

    if (mid_MsgQueueFO == NULL) {
        return -1;
    }

    return 0;
}
