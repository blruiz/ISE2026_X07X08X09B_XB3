#include "acelerometro.h"
#include <stdio.h>
#include <stdlib.h>

/* Definiciones de pines para el MPU6500 */
#define MPU6500_CS_PORT  GPIOD
#define MPU6500_CS_PIN   GPIO_PIN_14

#define MPU6500_MISO_PORT  GPIOA
#define MPU6500_MISO_PIN  GPIO_PIN_6

#define MPU6500_MOSI_PORT  GPIOB
#define MPU6500_MOSI_PIN  GPIO_PIN_5

/* Registros importantes del MPU6500 */
#define REG_READ_BIT     0x80 // MSB = 1 para lectura
#define REG_WHO_AM_I     0x75
#define REG_PWR_MGMT_1   0x6B
#define REG_ACCEL_XOUT_H 0x3B

#define S_TRANS_DONE_SPI  				0x01 // Flag de evento para sincronizar la comunicaci�n SPI con el hilo
#define FLAG_BUTTON        				0x04 //Flag para despertar hilo del sensor con la pulsaci�n del boton
#define FLAG_MOVIMIENTO_DETECTADO 0x08

/* --- DEFINICIONES DE REGISTROS MPU6500 (WOM - Wake on Motion) --- */
#define REG_ACCEL_CONFIG_2 0x1D
#define REG_INT_ENABLE     0x38
#define REG_INT_STATUS     0x3A
#define REG_WOM_THR        0x1F  // Umbral de movimiento
#define REG_LP_ACCEL_ODR   0x1E  // Frecuencia en modo bajo consumo
#define REG_ACCEL_INTEL_CTRL 0x69 // Control de inteligencia de aceleraci�n

/*Definici�n de funciones*/
void MPU_reset(void); //Configuraci�n inicial del hardware SPI y pines del MPU
void MPU_Init(void);  //Inicializaci�n del sensor
void MPU_WriteReg(uint8_t reg, uint8_t value); //Enviar datos al esclavo
uint8_t MPU_ReadReg(uint8_t reg); //Leer datos del esclavo
int Init_ThMPU (void); //Inicializaci�n del hilo del sensor
void SPI_Callback (uint32_t event); //

static void MPU_Read_burst(int16_t *x, int16_t *y, int16_t *z);

//static void initPINMPUReset(uint16_t GPIO_Pin);
static void initPINMPUcs(uint16_t GPIO_Pin);
void initTIMER7(void);
void delay(volatile uint32_t n_microsegundos);

/* Funciones para manejar la interrupci�n*/
void HAL_GPIO_EXTI_Callback(uint16_t pin);
void EXTI15_10_IRQHandler(void);
static void Init_EXTI(void);

void MPU_Config_WoM(uint8_t threshold);

/* Identificadores del RTOS */
osThreadId_t tid_ThMPU;                     // ID del hilo encargado del MPU

float gX,gY,gZ;
int16_t refX, refY, refZ;
uint32_t flags;

// --- GESTI�N DE BAJO NIVEL (SPI y HARDWARE) ---
// --- Variables de Control de Perif�ricos ---
extern ARM_DRIVER_SPI Driver_SPI1;	//Driver CMSIS para el bus SPI1
static ARM_DRIVER_SPI* SPIdrv = &Driver_SPI1;
static TIM_HandleTypeDef htim7; 		//Timer 7 para retardos precisos (microsegundos)

//Configuraci�n inicial del hardware SPI y pines del MPU
void MPU_reset(void){
	/* Initialize the SPI driver */
	SPIdrv->Initialize(SPI_Callback);
	/* Power up the SPI peripheral */
	SPIdrv->PowerControl(ARM_POWER_FULL);
	/* Configure the SPI to Master, 8-bit mode @1000 kBits/sec */
	SPIdrv->Control(ARM_SPI_MODE_MASTER | ARM_SPI_CPOL1_CPHA1 | ARM_SPI_MSB_LSB | ARM_SPI_DATA_BITS(8), 1000000);
	/* SS line = INACTIVE = HIGH */
	SPIdrv->Control(ARM_SPI_CONTROL_SS, ARM_SPI_SS_INACTIVE);
	
	//INICIALIZACI�N DE PINES
	initPINMPUcs(MPU6500_CS_PIN);
	HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_SET); // IDLE: CS en alto
	// 1. Reset interno del dispositivo
    MPU_WriteReg(REG_PWR_MGMT_1, 0x80);
	delay(1000);

}
//Inicialiizaci�n del sensor
void MPU_Init(void) {
    // 1. Configurar el SPI y los Pines
    // (Aseg�rate de que el SPI est� en Modo 3: CPOL=1, CPHA=1 como ten�as en el LCD)
    MPU_reset(); 
    printf("\r\n--- MPU6500 Debug Start ---\r\n");
    // 2. Comprobar conexi�n
    uint8_t id = MPU_ReadReg(REG_WHO_AM_I);
	  __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_9);
    __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_13);
	 printf("%u\r\n", id);
    if (id == 0x70) {
			  printf("Conexion exitosa con el sensor.\r\n");
        // 3. Despertar el sensor (Sale de Sleep Mode)
        // Escribimos 0x01 en PWR_MGMT_1 para usar el reloj del gir�scopo (m�s estable)
        MPU_WriteReg(REG_PWR_MGMT_1, 0x01);
				osDelay(2000); // Esperar a que el PLL se estabilice
			
				// 3. Configurar Wake-on-Motion (WoM)
				// El umbral (threshold) es 1 LSB = 4mg. 400mg / 4mg = 100
				MPU_Config_WoM(0xC8);
			
				printf("Calibrando reposo MPU6500...\r\n");
        //Tomamos una medida inicial como referencia
        MPU_Read_burst(&refX, &refY, &refZ); 
			  printf("Valores de calibraci�n: Acc X: %.2f g Acc Y: %.2f gAcc Z: %.2f g\r\n", (float)refX/16384.0f, (float)refY/16384.0f, (float)refZ/16384.0f);
    }else {
        printf("ERROR: No se detecta el sensor. Revisa el cableado.\r\n");
        while(1) osThreadYield(); // Detener si falla
    }
}
// Funci�n para escribir en un registro
void MPU_WriteReg(uint8_t reg, uint8_t value) {
    uint8_t data[2] = { reg, value }; // MSB = 0 para escritura
    
    HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_RESET); // CS Low
    SPIdrv->Send(data, 2);
    osThreadFlagsWait(S_TRANS_DONE_SPI, osFlagsWaitAny, osWaitForever);
    HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_SET); // CS High
}

		// Funci�n para leer un registro
		uint8_t MPU_ReadReg(uint8_t reg) {
    uint8_t tx[2] = { reg | REG_READ_BIT, 0x00 }; 
    uint8_t rx[2] = { 0, 0 };
    
    HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_RESET); // CS Low
		// Enviamos direcci�n y recibimos dato en una sola operaci�n full-duplex
    SPIdrv->Transfer(tx, rx, 2); 
    osThreadFlagsWait(S_TRANS_DONE_SPI, osFlagsWaitAny, osWaitForever);
    HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_SET); // CS High
    
    return rx[1]; // El dato real viene en el segundo byte
}

void Accelerometer_Thread (void *argument) {
    MPU_Init();
		Init_EXTI();
	
		// --- PASO CR�TICO: LIMPIEZA INICIAL ---
    osDelay(100); // Esperar a que las se�ales el�ctricas se estabilicen
    
    // 1. Limpiamos el hardware del sensor (leer borra los flags internos del MPU)
    MPU_ReadReg(REG_INT_STATUS); 
    
    // 2. Limpiamos los flags del RTOS que hayan podido saltar durante el arranque
    osThreadFlagsClear(FLAG_BUTTON | FLAG_MOVIMIENTO_DETECTADO);
	
    int16_t accX, accY, accZ;
	  //float threshold = 0.40f;  // Umbral de 0.4g para detectar movimiento
	  //uint32_t flags;
	
    while (1) {
				printf("Sistema en espera. Pulsa el BOTON AZUL para medir...\r\n");
        flags = 0;
        // El hilo se duerme hasta que pulses el bot�n
       flags = osThreadFlagsWait(FLAG_BUTTON, osFlagsWaitAny, osWaitForever);
			osDelay(50);
			 if (flags&0x04){
			  
			  MPU_ReadReg(REG_INT_STATUS);           // Limpia el hardware del sensor
        osThreadFlagsClear(FLAG_MOVIMIENTO_DETECTADO); // Limpia el flag del RTOS
			
			  //// Esperamos la interrupci�n del HARDWARE con un TIMEOUT (ej. 3 segundos)
        // Esto es perfecto para tu juego: si no golpea en 3s, pierde.
        flags = osThreadFlagsWait(FLAG_MOVIMIENTO_DETECTADO, osFlagsWaitAny, 5000);

        if (flags == FLAG_MOVIMIENTO_DETECTADO) {
					  MPU_Read_burst(&accX, &accY, &accZ);
            printf("�MOVIMIENTO DETECTADO! Gx:%.2f Gy:%.2f Gz:%.2f\r\n", (float)accX/16384.0f, (float)accY/16384.0f, (float)accZ/16384.0f);
            // Limpiamos el registro de interrupci�n del MPU leyendo INT_STATUS
            MPU_ReadReg(REG_INT_STATUS); 
					  
        } else {
            printf("�TIEMPO AGOTADO! Perdiste.\n");
        }
			}
        osDelay(1000); // Peque�a pausa antes de la siguiente ronda
		}
}

//Inicializa y crea el hilo del MPU
int Init_ThMPU (void) {  
	// Lanzamos el hilo que gestionar� la pantalla
	tid_ThMPU = osThreadNew(Accelerometer_Thread, NULL, NULL);
  
	if (tid_ThMPU == NULL) {
    return(-1);
  }
 
  return(0);
}

void SPI_Callback (uint32_t event){
    switch (event)
    {
    case ARM_SPI_EVENT_TRANSFER_COMPLETE:
        /* Success: Wakeup Thread */
        osThreadFlagsSet(tid_ThMPU, S_TRANS_DONE_SPI); 
        break;
    
    case ARM_SPI_EVENT_DATA_LOST:
        /*  Occurs in slave mode when data is requested/sent by master
            but send/receive/transfer operation has not been started
            and indicates that data is lost. Occurs also in master mode
            when driver cannot transfer data fast enough. */
        break;
    
    case ARM_SPI_EVENT_MODE_FAULT:
        /*  Occurs in master mode when Slave Select is deactivated and
            indicates Master Mode Fault. */
        break;
    }
}

void MPU_Read_burst(int16_t *x, int16_t *y, int16_t *z) {
    uint8_t buffer_rx[7] = {0};
    uint8_t reg_addr[7] = {REG_ACCEL_XOUT_H | 0x80};
	
		// Lectura en r�faga (Burst read) de 6 bytes (X_H, X_L, Y_H, Y_L, Z_H, Z_L)
    HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_RESET);
    // Transferencia completa: enviamos direcci�n y recibimos los 6 bytes a la vez
    SPIdrv->Transfer(reg_addr, buffer_rx, 7);
    osThreadFlagsWait(S_TRANS_DONE_SPI, osFlagsWaitAny, osWaitForever);
    HAL_GPIO_WritePin(GPIOD, MPU6500_CS_PIN, GPIO_PIN_SET);

    // Reconstrucci�n de los datos (Unir High byte y Low byte)
    *x = (int16_t)((buffer_rx[1] << 8) | buffer_rx[2]);
    *y = (int16_t)((buffer_rx[3] << 8) | buffer_rx[4]);
    *z = (int16_t)((buffer_rx[5] << 8) | buffer_rx[6]);

//		// Con sensibilidad por defecto (+/- 2g), 16384 LSB = 1g
//    gX = (float)*x / 16384.0f;
//		gY = (float)*y / 16384.0f;
//		gZ = (float)*z / 16384.0f;
//	 printf("Acc X: %.2f g Acc Y: %.2f gAcc Z: %.2f g\r\n", gX, gY, gZ);
}
	
// --- FUNCIONES DE CONTROL DE PINES (GPIO) ---

static void initPINMPUcs(uint16_t GPIO_Pin){
	
		GPIO_InitTypeDef GPIO_InitStruct = {0};
		
		__HAL_RCC_GPIOD_CLK_ENABLE();
    //Configuracion de los pines
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Pin = GPIO_Pin;

    //Inicializaci?n de los pines
    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);
}

//DELAY
/**
  * @brief  Configura el delay
	* @param  n_microsegundos -> tiempo establecido para realizar la pausa del delay; su valor se acota entre: 0-65534
  * @retval None
  */
void delay(volatile uint32_t n_microsegundos)
{
	initTIMER7();
	
	//Iniciamos el timer 7
  HAL_TIM_Base_Start(&htim7);
 
	//Esperamos a que se consuma el tiempo que hemos establecido en segundos
	while( __HAL_TIM_GET_COUNTER(&htim7) < n_microsegundos ){
		if (__HAL_TIM_GET_FLAG(&htim7, TIM_FLAG_UPDATE)) {
            __HAL_TIM_CLEAR_FLAG(&htim7, TIM_FLAG_UPDATE);
    } 
  }
	//Paramos el timer 7
	HAL_TIM_Base_Stop(&htim7);
	//Reiniciamos el contador del timer 7
	__HAL_TIM_SET_COUNTER(&htim7, 0);
}

/**
 * @brief Inicializa el Timer 7 para contar microsegundos.
 * Configuraci�n: Bus a 84MHz / Prescaler 83 = 1 tick por microsegundo.
 */
void initTIMER7(void){
	__HAL_RCC_TIM7_CLK_ENABLE();								// Habilitar reloj del perif�rico
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 83;									// Frecuencia = 84MHz / (83(valor prescaler) + 1) = 1 MHz
	htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 0xFFFF;									// Valor m�ximo de cuenta (16 bits)
  HAL_TIM_Base_Init(&htim7);
}

// --- GESTI�N DE INTERRUPCIONES ---
static void Init_EXTI(void){
/*Init boton azul*/
  __HAL_RCC_GPIOC_CLK_ENABLE();
  GPIO_InitTypeDef GPIO_InitStruct_Button = {0};
  GPIO_InitStruct_Button.Pin = GPIO_PIN_13;
  GPIO_InitStruct_Button.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct_Button.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC,&GPIO_InitStruct_Button);
	
/*Init se�al INT MPU*/
 __HAL_RCC_GPIOE_CLK_ENABLE();
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_PIN_9;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING; // El MPU pone un pulso alto
	GPIO_InitStruct.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
		
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0); // Prioridad segura para RTOS
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
	
	 HAL_NVIC_SetPriority(EXTI9_5_IRQn, 6, 0); // Prioridad segura para RTOS
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);
}

void EXTI15_10_IRQHandler(void){
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_13);
	
}

void EXTI9_5_IRQHandler(void){
  HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_9);
}
	
//void HAL_GPIO_EXTI_Callback(uint16_t pin){
//  if(pin==GPIO_PIN_13){
//    // Enviamos el FLAG para despertar al hilo del sensor
//    osThreadFlagsSet(tid_ThMPU, 0x04); // Usamos el bit 2 (0x04) para el bot�n
//  }
//}
/* Callback �nico para todas las interrupciones de GPIO */
void HAL_GPIO_EXTI_Callback(uint16_t pin) {
		 static uint32_t last_time_button = 0;
		 static uint32_t last_int_time = 0;
	
    if (pin == GPIO_PIN_13) { // Bot�n Azul
        uint32_t now = HAL_GetTick();
        if (now - last_time_button > 150) {   // 150 ms de debounce
            osThreadFlagsSet(tid_ThMPU, FLAG_BUTTON);
        }
        last_time_button = now;
    }
    if (pin == GPIO_PIN_9) {  // Pin INT del MPU
			 // MPU_ReadReg(REG_INT_STATUS);           // Limpia el hardware del sensor
        uint32_t now = HAL_GetTick();
				if (now - last_int_time > 30) {   // 30 ms evita dobles pulsos
						MPU_ReadReg(REG_INT_STATUS);
						osThreadFlagsSet(tid_ThMPU, FLAG_MOVIMIENTO_DETECTADO);
				}
				last_int_time = now;
    }
}

void MPU_Config_WoM(uint8_t threshold) {
// 1. Asegurar que el sensor no est� en Sleep y usar el reloj interno
    MPU_WriteReg(REG_PWR_MGMT_1, 0x00); 

    // 2. Configurar el Aceler�metro en modo "Standby" temporal para configurar
    // Registro PWR_MGMT_2 (0x6C): Desactivar Gir�scopo (bits 0,1,2) para ahorrar energ�a
    MPU_WriteReg(0x6C, 0x07); 

    // 3. Configurar el filtro paso bajo (DLPF)
    // Registro ACCEL_CONFIG_2 (0x1D): Importante para evitar que el ruido dispare el WoM
    MPU_WriteReg(REG_ACCEL_CONFIG_2, 0x03); // 41Hz de ancho de banda

    // 4. Habilitar la interrupci�n de WoM
    // Registro INT_ENABLE (0x38): Bit 6 (WOM_EN)
    MPU_WriteReg(REG_INT_ENABLE, 0x40);

    // 5. Establecer el umbral (Threshold)
    // Registro WOM_THR (0x1F): 1 LSB = 4mg.
    MPU_WriteReg(REG_WOM_THR, threshold);

    // 6. Configurar la inteligencia de movimiento
    // Registro ACCEL_INTEL_CTRL (0x69): 
    // Bit 7 (ACCEL_INTEL_EN), Bit 6 (ACCEL_INTEL_MODE - comparar con muestra anterior)
    MPU_WriteReg(REG_ACCEL_INTEL_CTRL, 0xC0);

    // 7. Establecer la frecuencia de muestreo en modo bajo consumo
    // Registro LP_ACCEL_ODR (0x1E): 0x06 corresponde a 31.25Hz (suficiente para detectar un golpe)
    MPU_WriteReg(REG_LP_ACCEL_ODR, 0x06);
		
		
    // 8. �PASO FINAL! Activar el Cycle Mode
    // Registro PWR_MGMT_1 (0x6B): Bit 5 (CYCLE)
    MPU_WriteReg(REG_PWR_MGMT_1, 0x20);
		/* Limpieza obligatoria antes de activar CYCLE */
    MPU_ReadReg(REG_INT_STATUS);
    delay(10);
}
