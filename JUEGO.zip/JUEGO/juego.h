#ifndef JUEGO_H
#define JUEGO_H

#include "cmsis_os2.h"
#include "stm32f4xx_it.h"

#define JUGAR      0x01
#define PAUSE      0x10
#define EVT_OK     0x02

#define START_SENSOR 0x04
#define END_SENSOR   0x08

#define COLA_SIZE  0x04
extern osMessageQueueId_t queue_ConsumoId;

typedef enum {
    MENU,
    JUGANDO,
} EstadoJuego;
		
extern int Init_Th_Juego (void);

osThreadId_t get_ThJuego_Id(void);
		
#endif // JUEGO_H
