#include "thread_palmada.h"
#include "adc.h"
#include "juego.h"
#include <stdbool.h>
#include <stdio.h>

static ADC_HandleTypeDef hadc;

void Thread_DetectarPalmada(void *argument);
static osThreadId_t tid_ThMic;

static const osThreadAttr_t threadMic_attr = {
  .stack_size = 512
};

static float voltage = 0.0f;
static bool palmada = false;
		
int Init_Th_Mic (void) {  
	tid_ThMic = osThreadNew(Thread_DetectarPalmada, NULL, &threadMic_attr);
  
	if (tid_ThMic == NULL) {
    return(-1);
  }
  return(0);
}

osThreadId_t get_ThPalmada_Id(){
  
  return tid_ThMic;
}
	
void Thread_DetectarPalmada(void *argument) {

    ADC_Init_Single_Conversion(&hadc, ADC1);

    while (1) {

        osThreadFlagsWait(START_SENSOR, osFlagsWaitAny, osWaitForever);
        osThreadFlagsClear(END_SENSOR);

        palmada = false;

        while (!palmada) {

            if (osThreadFlagsWait(END_SENSOR, osFlagsWaitAny, 0) == END_SENSOR) {
                break;
            }

            voltage = ADC_getVoltage(&hadc, ADC_CHANNEL_10);

            if ((voltage > PALMADA_THRESHOLD_MAX) ||
                (voltage < PALMADA_THRESHOLD_MIN)) {
                  
//                if (osThreadFlagsGet() & END_SENSOR) {    // ? comprobaci�n final
//                    break;
//                }
                palmada = true;
                osThreadFlagsSet(get_ThJuego_Id(), EVT_OK);
            }
            osDelay(2);
        }
    }
}


/*
static float filtered = 0.0f;
static int initialized = 0;
float alpha = 0.9f;
float threshold = 0.20f;   // 200 mV

// 1. Leer el ADC
voltage = ADC_getVoltage(&hadc, ADC_CHANNEL_10);

// 2. Inicializar el filtro la primera vez
if (!initialized) {
    filtered = voltage;
    initialized = 1;
}

// 3. Actualizar el nivel medio (ventana �lenta�)
filtered = alpha * filtered + (1.0f - alpha) * voltage;

// 4. Diferencia entre la muestra y el nivel medio
float diff = fabsf(voltage - filtered);

// 5. Detectar pico (palmada)
if (diff > threshold) {
    palmada = true;
    HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0, GPIO_PIN_SET);
    osTimerStop(timerPalmada);
}
*/
