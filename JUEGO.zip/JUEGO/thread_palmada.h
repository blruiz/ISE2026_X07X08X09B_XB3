#ifndef THREAD_PALMADA_H
#define THREAD_PALMADA_H

#include "cmsis_os2.h"
#include "stm32f4xx_it.h"

#define PALMADA_THRESHOLD_MAX 1.85f 
#define PALMADA_THRESHOLD_MIN 1.55f 

extern int Init_Th_Mic (void);
osThreadId_t get_ThPalmada_Id(void);

#endif // THREAD_PALMADA_H
