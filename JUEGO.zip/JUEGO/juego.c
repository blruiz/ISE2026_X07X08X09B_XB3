#include "juego.h"
#include "thread_palmada.h"
#include "bajo_consumo.h"
#include "adc.h"
#include "acelerometro.h"
#include "thread_consumo.h"
#include "usart.h"
#include "infrarrojo.h"
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void Thread_Juego(void *argument);
void init_Threads(void);
static osThreadId_t tid_ThJuego;

static uint16_t tiempoActual_ms = 5000;   // el timer del juego empieza en 5s
static const uint32_t decremento_ms = 200;
static const uint32_t tiempo_min_ms = 2000;

static uint16_t puntos = 0;
static uint16_t consumo = 0;

osMessageQueueId_t queue_ConsumoId;
    
EstadoJuego estadoActual;

static uint8_t accionActual = 0;

static uint8_t elegirAccionAleatoria(uint8_t accionAnterior);

extern volatile uint8_t system_sleep;

static const osThreadAttr_t threadJuego_attr = {
  .priority = osPriorityHigh,
  .stack_size = 512
};


int Init_Th_Juego (void) {  
	// Lanzamos el hilo que gestionar� la pantalla
	tid_ThJuego = osThreadNew(Thread_Juego, NULL, &threadJuego_attr);
  
	if (tid_ThJuego == NULL) {
    return(-1);
  }
	
  return(0);
}
osThreadId_t get_ThJuego_Id(){
  
  return tid_ThJuego;
}

void Thread_Juego(void *argument) {
	  queue_ConsumoId = osMessageQueueNew(COLA_SIZE, sizeof(uint16_t), NULL);
	  init_Threads();
		osStatus_t status;
    estadoActual = MENU;
	  uint32_t flags, tick_ini, tiempo_consumido,tiempo_restante_ms,timeout_ms;
    estadoActual = MENU;
    osDelay(2500);
//printf("Esperando inicio de partida, pulsa JUGAR\n");
    while (1) {
      
      status = osMessageQueueGet(queue_ConsumoId, &consumo, NULL, 0);
      if (status == osOK) {
//printf("Consumo recibido: %d mA\n", consumo);
          enviarDatos(CONSUMO, consumo);
			}
  
      switch (estadoActual) {
        case MENU:
            tiempoActual_ms = 5000;
            accionActual = 0;
            tiempo_restante_ms = 0;
            
            flags = osThreadFlagsWait(JUGAR,osFlagsWaitAny,1000);      //LLEGA EL FLAG DESDE EL SERVIDOR
        
            if ((flags & osFlagsError) == 0 && (flags & JUGAR))  {
//printf("Iniciando partida\n");
              puntos = 0;
              enviarDatos(PUNTOS, puntos); //llama a la funcion para crear el mensaje de enviar puntos
              estadoActual = JUGANDO;
              srand(osKernelGetTickCount()); //inicializa la semilla de aleatorizaci�n
            }
            break;

        case JUGANDO:
          
             if (tiempo_restante_ms == 0) {
                accionActual = elegirAccionAleatoria(accionActual);
               }
//printf("Realiza acci�n: %d\n",accionActual);
            osThreadFlagsClear(EVT_OK | PAUSE);
  
            switch (accionActual) {    
                case 0x01: //PALMADA
                    osThreadFlagsSet(get_ThPalmada_Id(),START_SENSOR);
                    enviarDatos(ACCION, PALMADA);
                    break;
                case 0x02: //MOVIMIENTO
                    osThreadFlagsSet(get_ThMPU_Id(),START_SENSOR);
                    enviarDatos(ACCION, MOVIMIENTO);
                    break;
                case 0X03: // GESTO
                    osThreadFlagsSet(get_ThIR_Id(),START_SENSOR);
                    enviarDatos(ACCION, GESTO);
                    break;
                default:    
//                    printf("ERROR accion invalida: %d\n", accionActual);    
                    estadoActual = MENU;    
                    continue;
            }
            timeout_ms = (tiempo_restante_ms > 0) ? tiempo_restante_ms : tiempoActual_ms;
            tick_ini = osKernelGetTickCount();
            
            flags = osThreadFlagsWait(EVT_OK | PAUSE,osFlagsWaitAny,timeout_ms);
            
            
                if ((flags & osFlagsError) == 0) {

                    // PAUSA
                    if (flags & PAUSE) {

                        tiempo_consumido = osKernelGetTickCount() - tick_ini;

                        if (tiempo_consumido >= timeout_ms) {
                            tiempo_restante_ms = 1;
                        } else {
                            tiempo_restante_ms = timeout_ms - tiempo_consumido;
                        }

                        // Parar sensor activo
                        switch (accionActual) {
                            case 0x01:
                                osThreadFlagsSet(get_ThPalmada_Id(), END_SENSOR);
                                break;
                            case 0x02:
                                osThreadFlagsSet(get_ThMPU_Id(), END_SENSOR);
                                break;
                            case 0x03:
                                osThreadFlagsSet(get_ThIR_Id(), END_SENSOR);
                                break;
                        }

                        enviarDatos(PAUSE, 0x00);
//printf("PAUSA\n");
                        // Esperar a que el sistema despierte antes de seguir
                        while (system_sleep) {
                            osDelay(10);
                        }
                    }
                    // EVT_OK
                    else if (flags & EVT_OK) {

                        puntos += 1;
                        tiempo_restante_ms = 0;

                        if (tiempoActual_ms > tiempo_min_ms) {
                            tiempoActual_ms -= decremento_ms;
                            if (tiempoActual_ms < tiempo_min_ms) {
                                tiempoActual_ms = tiempo_min_ms;
                            }
                        }
                        tiempo_restante_ms = 0;
                        enviarDatos(PUNTOS, puntos);
                    }
                }
                //  timeout
                else {

                    switch (accionActual) {
                        case 0x01:
                            osThreadFlagsSet(get_ThPalmada_Id(), END_SENSOR);
                            break;
                        case 0x02:
                            osThreadFlagsSet(get_ThMPU_Id(), END_SENSOR);
                            break;
                        case 0x03:
                            osThreadFlagsSet(get_ThIR_Id(), END_SENSOR);
                            break;
                    }

                    osDelay(10);

                    estadoActual = MENU;
                    tiempo_restante_ms = 0;
//printf("fIN\n");
                    enviarDatos(GAME_OVER, 0x00);
                    osThreadFlagsClear(EVT_OK | PAUSE);
                }

                break;
        }
 
        osDelay(10);
    }

}

//static uint8_t elegirAccionAleatoria() {
//    return (uint8_t)(rand() % 3)+1;
//}

static uint8_t elegirAccionAleatoria(uint8_t accionAnterior) {

    // Primera acci�n de la partida: libre
    if (accionAnterior ==0) {
        return (uint8_t)(rand() % 3) + 1;
    }

    // Elegir una de las dos acciones distintas a la anterior
    uint8_t offset = (uint8_t)(rand() % 2) + 1;

    // Resultado siempre en el rango 1..3 y distinto de accionAnterior
    return (uint8_t)(((accionAnterior - 1 + offset) % 3) + 1);
}

void init_Threads(){
  ADC1_pins_F429ZI_config();
  Init_ThMPU();
  Init_FO();
  Init_Th_Mic();
  Init_ThConsumo();
  Init_ThIR();
  Init_Th_BajoConsumo();
}
