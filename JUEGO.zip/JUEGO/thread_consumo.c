#include "thread_consumo.h"
#include "adc.h"
#include "juego.h"
#include <stdio.h>

static ADC_HandleTypeDef hadc2;

void Thread_Consumo(void *argument);
static osThreadId_t tid_ThConsumo;

static const osThreadAttr_t threadConsumo_attr = {
  .stack_size = 512
};

static const float GANANCIA    = 100.0f;
static const float RESISTENCIA = 0.13f;

static float volt_local = 0.0f;
static uint16_t consumo_local = 0;

int Init_ThConsumo (void) {  

	tid_ThConsumo = osThreadNew(Thread_Consumo, NULL, &threadConsumo_attr);
  
	if (tid_ThConsumo == NULL) {
    return(-1);
  }
	
  return(0);
}

osThreadId_t get_ThConsumo_Id(){
  
  return tid_ThConsumo;
}

void Thread_Consumo(void *argument) {
    
    ADC_Init_Single_Conversion(&hadc2, ADC2);
		osStatus_t status;
    osDelay(3000);
    while (1) {
        volt_local = ADC_getVoltage(&hadc2, ADC_CHANNEL_13);
			  consumo_local = (uint8_t)(1000*volt_local/(GANANCIA*RESISTENCIA)); //en mA
//				printf("Voltaje: %d mV, Consumo: %d mA\n", (uint16_t)(volt_local*1000), consumo_local);
				status = osMessageQueuePut(queue_ConsumoId, &consumo_local, 0, 0);
			
				if (status != osOK) {
//					printf("Cola consumo llena, dato perdido\n");
				}

        osDelay(10000); //delay 10seg
    }
}
/**
void Thread_Consumo(void *argument) {
    ADC_Init_Single_Conversion(&hadc2, ADC2);

    uint32_t sumaConsumo = 0;
    uint16_t muestras = 0;
    uint16_t consumoPromedio = 0;

    while (1) {
        voltage = ADC_getVoltage(&hadc2, ADC_CHANNEL_13);
        consumo = (uint16_t)((1000 * voltage) / (GANANCIA * RESISTENCIA)); // en mA

        sumaConsumo += consumo;
        muestras++;

        if (muestras >= 10) {  // 10 muestras a 1s = 10 segundos
            consumoPromedio = sumaConsumo / muestras;
            osMessageQueuePut(queue_ConsumoId, &consumoPromedio, 0, 0);
            sumaConsumo = 0;
            muestras = 0;
        }

        osDelay(1000);  // 1 segundo entre muestras
    }
}
**/
