#include "bajo_consumo.h"
#include "juego.h"

osThreadId_t tid_Th_BC;

/* Private function prototypes */
void Thread_BC(void *argument);
void enter_sleep_mode(void);
void Init_UserButton(void);

volatile uint8_t system_sleep = 0;

static const osThreadAttr_t threadBC_attr = {
  .stack_size = 256
};

int Init_Th_BajoConsumo (void){
  tid_Th_BC = osThreadNew(Thread_BC, NULL, &threadBC_attr);

  if (tid_Th_BC == NULL){
    return -1;
  }
  return 0;
}

osThreadId_t get_ThBC_Id(){
  return tid_Th_BC;
}

/* ----------------------------- */
/* HILO BAJO CONSUMO */
/* ----------------------------- */
void Thread_BC(void *argument){

    Init_UserButton();

    uint32_t last_button_tick = 0;

    while(1){

        // Esperar pulsaci�n
        osThreadFlagsWait(0x01, osFlagsWaitAny, osWaitForever);

        uint32_t now = osKernelGetTickCount();

        // ? ANTIRREBOTES
        if ((now - last_button_tick) < 500) {
            continue;
        }
        last_button_tick = now;
//printf("A dormir\n");
        // ? limpiar flags antes de procesar
        osThreadFlagsClear(0x01);

        system_sleep = 1;
        // ? Avisar al juego
        osThreadFlagsSet(get_ThJuego_Id(), PAUSE);

        // ? Dar tiempo real para guardado seguro
        osDelay(50);

        // -------------------------
        // PREPARAR SLEEP
        // -------------------------
        

        // ? bloquear fuentes de wake no deseadas
        HAL_NVIC_DisableIRQ(UART7_IRQn); 
        EXTI->IMR &= ~EXTI_IMR_MR12;             // IR

        // ? limpiar todo justo antes de dormir
        __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_13);
        NVIC_ClearPendingIRQ(EXTI15_10_IRQn);

        // -------------------------
        // ENTRAR EN SLEEP
        // -------------------------
        enter_sleep_mode();

        // -------------------------
        // WAKE-UP
        // -------------------------
        system_sleep = 0;
//printf("A trabajar\n");
        // ? restaurar fuentes de interrupci�n
        HAL_NVIC_EnableIRQ(UART7_IRQn);
        EXTI->IMR |= EXTI_IMR_MR12;

        // ? limpiar rebotes residuales tras wake
        __HAL_GPIO_EXTI_CLEAR_IT(GPIO_PIN_13);
        osThreadFlagsClear(0x01);

        // ? peque�o delay para estabilizar (NO grande)
        osDelay(50);
    }
}

/* ----------------------------- */
/* ENTRADA EN MODO SLEEP */
/* ----------------------------- */
void enter_sleep_mode(void){

    // Opcional: apagar perif�ricos que consumen
    __HAL_RCC_GPIOF_CLK_DISABLE();
    __HAL_RCC_GPIOE_CLK_DISABLE();
    __HAL_RCC_USB_OTG_FS_CLK_DISABLE();

    // ? detener tick RTOS
    HAL_SuspendTick();

    __DSB();
    __ISB();

    HAL_PWR_EnterSLEEPMode(PWR_MAINREGULATOR_ON, PWR_SLEEPENTRY_WFI);

    HAL_ResumeTick();

    // Restaurar clocks
    __HAL_RCC_USB_OTG_FS_CLK_ENABLE();
    __HAL_RCC_GPIOF_CLK_ENABLE();
    __HAL_RCC_GPIOE_CLK_ENABLE();
}

/* ----------------------------- */
/* CONFIG BOT�N */
void Init_UserButton(void){

    GPIO_InitTypeDef GPIO_InitStruct_Button = {0};
    GPIO_InitStruct_Button.Pin = GPIO_PIN_13;
    GPIO_InitStruct_Button.Mode = GPIO_MODE_IT_RISING;
    GPIO_InitStruct_Button.Pull = GPIO_PULLDOWN;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct_Button);

}
